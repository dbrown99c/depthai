from .abstract_trigger import Trigger
from .detection_trigger import DetectionTrigger
